package com.reactive.practice.springreactor.controller;

import com.reactive.practice.springreactor.model.Order;
import com.reactive.practice.springreactor.service.OrderService;
import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderService orderService;


    @GetMapping("/{id}")
    public Publisher<Order> getById(@PathVariable(value = "id")String id) {
        return orderService.findById(id);
        /*Order item = new Order();
        item.setDescription (  );*/

    }


    @RequestMapping(value = "/orderNo", method = RequestMethod.GET, produces = "application/json")
    public Mono<Order> getByOrderNo(@RequestParam(required = true) String orderNumber) {
        return orderService.findByOrderNo(orderNumber);
        /*Order item = new Order();
        item.setDescription (  );*/

    }


    @RequestMapping(value = "/orderNo/{orderNumber}", method = RequestMethod.GET, produces = "application/json")
    public Order getByOrderNo1(@PathVariable("orderNumber") String orderNumber) {
        return orderService.findByOrderNo1(orderNumber);
        /*Order item = new Order();
        item.setDescription (  );*/

    }

    @RequestMapping(value = "/orderNumber/{orderNumber}", method = RequestMethod.GET, produces = "application/json")
    public Mono<ResponseEntity<Order>> getByOrderNo2(@PathVariable("orderNumber") String orderNumber) {
        return orderService.findByOrderNo2(orderNumber);
    }




    /*@RequestMapping(value = "/getDiscount", method = RequestMethod.GET, produces = "application/json")
    public Order getDiscountBasedOnType(@RequestParam(required = true) String type) {

        Item item = new Item();
        item.setType(type);

        itemservice.getItemDiscount(item);

        return item;


    }*/
}
