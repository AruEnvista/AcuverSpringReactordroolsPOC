package com.landmark.refundCalculation.model.oms;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class SalesOrderLines {
    @NonNull
    private BigDecimal ordered_quantity;

    @NonNull
    private String department_code;

    @NonNull //adding for test
    private String status;

    @NonNull //adding for test
    private BigDecimal statusQty;

    @NonNull //adding for test
    private String deliveryType;

    private boolean return_window_period;

    @NonNull
    private String prime_line_number;

    private String sub_line_number;

    @NonNull
    private BigDecimal returnable_quantity;

    private List<LineCharge> line_charges;

    private List<LineTax> line_taxes;

    private List<LinePriceInformation> line_price_information;

    private ItemDetails item_details;

    private List<OrderStatus> order_statuses;

}
