package com.landmark.refundCalculation.model.oms;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
@Document("landmarkDB")
public class SalesOrderResponse {
    @NonNull
    private String enterprise_code;

    private BigDecimal document_type;

    private Date order_date;

    @NonNull
    @Field("order_number")
    private String orderNumber;

    private List<SalesOrderLines> order_lines;

    private List<HeaderCharge> header_charges;

    private List<HeaderTax> header_taxes;

    private List<PaymentMethod> payment_methods;

}
