package com.landmark.refundCalculation.controller;

import com.landmark.refundCalculation.model.request.ExternalSystemOrderRequest;
import com.landmark.refundCalculation.model.request.ExternalSystemOrderResponse;
import com.landmark.refundCalculation.service.RefundCalculationService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.reactivestreams.Publisher;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class RefundCalculationController {

    public static final Logger LOG = LoggerFactory.getLogger(RefundCalculationController.class);

    private RefundCalculationService refundCalculationService;

    RefundCalculationController(RefundCalculationService refundCalculationService) {
        this.refundCalculationService = refundCalculationService;
    }

    /**
     * The release order operation
     *
     * @param orderNumber   - customer-order-id
     * @param orderRequest - payload
     * @return the list of requests keyed by the sales order ids
     */
    @PostMapping("/customer-orders/{customer-order-id}/return-refund-enquiry")
    @ApiOperation(value = "Refund Enquiry API")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success",response=ExternalSystemOrderResponse.class),
            @ApiResponse(code = 500, message = "Internal server error"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 404, message = "Not Found")
    })
    public Publisher<ResponseEntity<ExternalSystemOrderResponse>> refundCalculation(@PathVariable("customer-order-id") String orderNumber, @RequestBody ExternalSystemOrderRequest orderRequest){
        LOG.info ( "Log the Input message:-"+ orderRequest );
        return refundCalculationService.getRefundAmount(orderRequest);
    }
}
