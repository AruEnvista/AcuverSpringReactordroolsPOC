package com.landmark.refundCalculation.service;

import com.landmark.refundCalculation.mapper.BusinessMapper;
import com.landmark.refundCalculation.model.oms.SalesOrderLines;
import com.landmark.refundCalculation.model.oms.SalesOrderResponse;
import com.landmark.refundCalculation.model.request.ExternalSystemOrderRequest;
import com.landmark.refundCalculation.model.request.ExternalSystemOrderResponse;
import com.landmark.refundCalculation.repository.SalesOrderResponseRepository;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.StatelessKieSession;
import org.reactivestreams.Publisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;

@Service
public class RefundCalculationService {

    public static final Logger LOG = LoggerFactory.getLogger( RefundCalculationService.class);

    private BusinessMapper mapper;
    private KieContainer kieContainer;
    private SalesOrderResponseRepository repo;

    RefundCalculationService(BusinessMapper mapper, KieContainer kieContainer, SalesOrderResponseRepository repo) {
        this.mapper = mapper;
        this.kieContainer = kieContainer;
        this.repo = repo;
    }

    private String sessionName = "ksession-rule";


    public Publisher<ResponseEntity<ExternalSystemOrderResponse>> getRefundAmount(ExternalSystemOrderRequest orderRequest) {

        long t1 =System.currentTimeMillis ();

        SalesOrderResponse order1 = new SalesOrderResponse();
        order1.setEnterprise_code ( "UAE");
        order1.setOrderNumber ( "0090019" );
        order1.setOrder_date ( new java.util.Date (2019,11,24 ) );
        SalesOrderLines s= new SalesOrderLines (  );
        s.setStatus ( "3700.7777" );
        s.setStatusQty (new BigDecimal ( 3 ) );
        s.setDeliveryType ( "HD" );
        s.setDepartment_code ( "01" );

        SalesOrderLines s1= new SalesOrderLines (  );
        s1.setStatus ( "3700.100" );
        s1.setStatusQty (new BigDecimal ( 3 ) );
        s1.setDeliveryType ( "CC" );
        s1.setDepartment_code ( "02" );
        order1.setOrder_lines ( Arrays.asList (s,s1));
        //repo.insert(order1).subscribe ();





        StatelessKieSession kieSession = kieContainer.newStatelessKieSession(sessionName);
        //KieSession kieSession = kieContainer.newKieSession (sessionName);
        Mono<SalesOrderResponse> omsSalesOrderResponse = repo.findByOrderNumber(orderRequest.getCustomer_order_id ())
                .flatMap ( existingProduct -> {
                    System.out.println("Order Date before rules"+
                            new SimpleDateFormat ( "yyyy/MM/dd" )
                                    .format (existingProduct.getOrder_date ()));
            kieSession.execute ( existingProduct );
            /*kieSession.insert ( existingProduct );
            kieSession.insert ( orderRequest );
            kieSession.fireAllRules ();
            kieSession.dispose ();*/
            return Mono.just ( existingProduct ).log ("Log the outPut message111:-"+existingProduct);
        } );
               /* .switchIfEmpty ( orderDAO.findByOrderNo ( orderNumber ).flatMap ( existingProduct -> {
            kieSession.insert ( existingProduct );
            kieSession.fireAllRules ();
            kieSession.dispose ();
            return Mono.just ( existingProduct );
        } ).map ( o3 -> ResponseEntity.ok ( o3 ) )
                .defaultIfEmpty ( ResponseEntity.notFound ().build () ) ).log ();*/
        /*return ExternalSystemOrderResponse*/
        Mono<ExternalSystemOrderResponse> externalOrderResponse = mapper.MapFromSalesOrderToOrder(omsSalesOrderResponse);
        long t2 =System.currentTimeMillis ();
        LOG.info ( "total time:-"+(t2-t1) );



        return externalOrderResponse.map ( o1 -> ResponseEntity.status ( HttpStatus.OK ).body ( o1 ) )
                .defaultIfEmpty ( ResponseEntity.notFound ().build () );
    }
}
