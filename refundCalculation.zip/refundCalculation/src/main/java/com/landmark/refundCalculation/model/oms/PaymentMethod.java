package com.landmark.refundCalculation.model.oms;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class PaymentMethod {
    @NonNull
    private String payment_type;

    @NonNull
    private BigDecimal amount;

    @NonNull
    private String payment_reference3;

    @NonNull
    private String payment_reference4;

}
