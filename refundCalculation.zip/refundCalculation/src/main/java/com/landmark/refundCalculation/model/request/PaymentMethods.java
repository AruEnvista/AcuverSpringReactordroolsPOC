package com.landmark.refundCalculation.model.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class PaymentMethods {
    private String payment_type;
    private String payment_code;
    private String amount;
    private String voucher_code;
}
