package com.landmark.refundCalculation;

import com.landmark.refundCalculation.model.request.ExternalSystemOrderRequest;
import com.landmark.refundCalculation.model.request.OrderLines;
import com.landmark.refundCalculation.service.RefundCalculationService;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.WebTestClient;
import java.math.BigDecimal;
import java.util.Arrays;


@RunWith(SpringRunner.class)
@WebFluxTest
@SpringBootTest
class RefundCalculationApplicationTests {

	@Autowired
	private WebTestClient webTestClient;

	@MockBean
	private RefundCalculationService refundCalculationService;

	@Test
	public void automateAPI() {
		ExternalSystemOrderRequest request = new ExternalSystemOrderRequest();
		request.setCustomer_order_id ("12345");
		request.setIs_guest_user ("N");
		request.setDelivery_type ("HD");
		request.setEnterprise_code ("LMG_UAE / LMG_BAH");
		request.setSource ( "HYBRIS / POS" );
		request.setIs_refund_option_required ( "Y" );
		request.setIs_ieb_required ( "N" );
		OrderLines lines = new OrderLines();
		lines.setItem_id ( "10000000" );
		lines.setReturn_quantity (new BigDecimal ( 2 ));
		request.setOrder_lines ( Arrays.asList (lines) );
		Mockito.when(refundCalculationService.getRefundAmount(request));
		webTestClient.get()
				.uri("/api/v1/customer-orders/{customer-order-id}/return-refund-enquiry")
				.exchange()
				.expectStatus().isOk();

		}

	}


