package com.landmark.refundCalculation.model.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class RefundOptions {
    private String mode;
    private String cash_refund;
    private BigDecimal wallet_amount;
    private BigDecimal total_Loyalty_refund_amount;
    private BigDecimal non_refunded_voucher_amount;
    private BigDecimal delivery_cost;
    private BigDecimal payment_cost;
    private BigDecimal loyalty_recovery_amount;
    private List<PaymentMethods> payment_methods;

}
