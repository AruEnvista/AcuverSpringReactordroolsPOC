package com.landmark.refundCalculation.service;

import com.landmark.refundCalculation.mapper.BusinessMapper;
import com.landmark.refundCalculation.model.oms.SalesOrderResponse;
import com.landmark.refundCalculation.model.request.ExternalSystemOrderRequest;
import com.landmark.refundCalculation.model.request.ExternalSystemOrderResponse;
import com.landmark.refundCalculation.repository.SalesOrderResponseRepository;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.reactivestreams.Publisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class RefundCalculationService {

    public static final Logger LOG = LoggerFactory.getLogger( RefundCalculationService.class);

    @Autowired
    private BusinessMapper mapper;

    @Autowired
    private KieContainer kieContainer;

    private String sessionName = "ksession-rule";

    @Autowired
    private SalesOrderResponseRepository repo;

    public Publisher<ResponseEntity<ExternalSystemOrderResponse>> getRefundAmount(ExternalSystemOrderRequest orderRequest) {
        long t1 =System.currentTimeMillis ();
        KieSession kieSession = kieContainer.newKieSession (sessionName);
        Mono<SalesOrderResponse> omsSalesOrderResponse = repo.findByOrderNumber(orderRequest.getCustomer_order_id ())
                .flatMap ( existingProduct -> {
            /*kieSession.execute ( existingProduct );*/
            kieSession.insert ( existingProduct );
            kieSession.fireAllRules ();
            kieSession.dispose ();
            return Mono.just ( existingProduct ).log ("Log the outPut message:-"+existingProduct);
        } );
               /* .switchIfEmpty ( orderDAO.findByOrderNo ( orderNumber ).flatMap ( existingProduct -> {
            kieSession.insert ( existingProduct );
            kieSession.fireAllRules ();
            kieSession.dispose ();
            return Mono.just ( existingProduct );
        } ).map ( o3 -> ResponseEntity.ok ( o3 ) )
                .defaultIfEmpty ( ResponseEntity.notFound ().build () ) ).log ();*/
        /*return ExternalSystemOrderResponse*/
        Mono<ExternalSystemOrderResponse> externalOrderResponse = mapper.MapFromSalesOrderToOrder(omsSalesOrderResponse);
        long t2 =System.currentTimeMillis ();
        LOG.info ( "total time:-"+(t2-t1) );

        return externalOrderResponse.map ( o1 -> ResponseEntity.ok ( o1 ) )
                .defaultIfEmpty ( ResponseEntity.notFound ().build () );
    }
}
