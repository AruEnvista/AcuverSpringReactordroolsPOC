package com.landmark.refundCalculation.model.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class ExternalSystemOrderRequest {
    private String customer_order_id;
    private String enterprise_code;
    private String is_guest_user;
    private String delivery_type;
    private String source;
    private String is_refund_option_required;
    private String is_ieb_required;
    private List<OrderLines> order_lines;
}
