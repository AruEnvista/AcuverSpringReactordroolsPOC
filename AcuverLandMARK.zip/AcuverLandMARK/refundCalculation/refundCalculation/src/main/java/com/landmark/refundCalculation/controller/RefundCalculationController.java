package com.landmark.refundCalculation.controller;

import com.landmark.refundCalculation.model.request.ExternalSystemOrderRequest;
import com.landmark.refundCalculation.model.request.ExternalSystemOrderResponse;
import com.landmark.refundCalculation.service.RefundCalculationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class RefundCalculationController {

    public static final Logger LOG = LoggerFactory.getLogger(RefundCalculationController.class);

    @Autowired
    private RefundCalculationService refundCalculationService;

    @PostMapping("/customer-orders/{customer-order-id}/return-refund-enquiry")
    public Publisher<ResponseEntity<ExternalSystemOrderResponse>> refundCalculation(@RequestBody ExternalSystemOrderRequest orderRequest){
        LOG.info ( "Log the Input message:-"+ orderRequest );
        return refundCalculationService.getRefundAmount(orderRequest);
    }
}
