package com.landmark.refundCalculation;

import org.kie.api.KieServices;
import org.kie.api.cdi.KContainer;
import org.kie.api.cdi.KReleaseId;
import org.kie.api.runtime.KieContainer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class RefundCalculationApplication {

	public static void main(String[] args) {
		SpringApplication.run(RefundCalculationApplication.class, args);
	}

	@Bean
	@KContainer
	@KReleaseId(groupId = "com.landmark",artifactId = "returnpolicyrules", version = "0.0.1-SNAPSHOT")
	public KieContainer kieContainer() {
		return KieServices.Factory.get().getKieClasspathContainer();
	}


}
