package com.landmark.refundCalculation.model.oms;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.mapping.Document;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
@Document("landmarkDB")
public class SalesOrderResponse {
    @NonNull
    private String enterprise_code;

    private BigDecimal document_type;

    private Date order_date;

    private boolean isLegacyOrder;

    @NonNull
    private String orderNumber;

    private List<SalesOrderLines> order_lines;

    private List<HeaderCharge> header_charges;

    private List<HeaderTax> header_taxes;

    private List<PaymentMethod> payment_methods;

}
