package com.landmark.refundCalculation.mapper;

import com.landmark.refundCalculation.model.oms.SalesOrderRequest;
import com.landmark.refundCalculation.model.oms.SalesOrderResponse;
import com.landmark.refundCalculation.model.request.ExternalSystemOrderRequest;
import com.landmark.refundCalculation.model.request.ExternalSystemOrderResponse;
import com.landmark.refundCalculation.model.request.OrderLines;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class BusinessMapper {

    public SalesOrderRequest MapFromOrderToSalesOrder(ExternalSystemOrderRequest orderRequest) {
        SalesOrderRequest salesOrder = new SalesOrderRequest();
        salesOrder.setEnterprise_code ( orderRequest.getEnterprise_code () );
        salesOrder.setCustomer_order_number ( orderRequest.getCustomer_order_id () );
        return salesOrder;
    }

    public Mono<ExternalSystemOrderResponse> MapFromSalesOrderToOrder(Mono<SalesOrderResponse> omsSalesOrderResponse) {
        ExternalSystemOrderResponse response = new ExternalSystemOrderResponse();
        return omsSalesOrderResponse.flatMap ( existingProduct -> {
            response.setCustome_order_id ( existingProduct.getOrderNumber () );
            response.setEnterprise_code ( existingProduct.getEnterprise_code () );
            response.setSource ( existingProduct.getDocument_type ().toString () );
            response.set_Legacy_order ( existingProduct.isLegacyOrder () );
            List<OrderLines> returnLines = existingProduct.getOrder_lines ().stream ().map (
                    line -> {
                        OrderLines orderLines = new OrderLines ();
                        orderLines.setItem_id ( line.getItem_details ().getItem_identifier () );
                        orderLines.setReturn_quantity ( line.getReturnable_quantity () );
                        return orderLines;
                    } ).collect ( Collectors.toList () );
            response.setOrder_lines (returnLines);
            return Mono.just ( response ).log ();
        } );
    }
}
