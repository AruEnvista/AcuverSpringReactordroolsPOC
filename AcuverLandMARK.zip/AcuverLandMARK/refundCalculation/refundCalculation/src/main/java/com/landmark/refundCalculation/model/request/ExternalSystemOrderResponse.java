package com.landmark.refundCalculation.model.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class ExternalSystemOrderResponse {
    private String custome_order_id;
    private String enterprise_code;
    private String status;
    private String source;
    private String total_refund_option;
    private List<RefundOptions> refund_options;
    private List<OrderLines> order_lines;
    private boolean is_Legacy_order; //test
}
