package com.landmark.refundCalculation.repository;

import com.landmark.refundCalculation.model.oms.SalesOrderResponse;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Mono;

public interface SalesOrderResponseRepository extends ReactiveMongoRepository<SalesOrderResponse, String> {
    Mono<SalesOrderResponse> findByOrderNumber(String customerOrderId);
}
