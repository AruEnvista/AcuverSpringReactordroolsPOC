package com.landmarkgroup.api.returnpolicyenquiry.apps.ExternalRequestAndResponseModel.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class ExternalOrderLines {
    @NonNull
    private String item_id;

    private String item_description;

    private BigDecimal maximum_returnable_quantity;

    private boolean is_returnable=false;

    private boolean with_in_return_window=false;

    private BigDecimal return_window_period;

    @NonNull
    private BigDecimal ordered_quantity;

    @NonNull
    private String department_code;

    private String delivery_type;
}
