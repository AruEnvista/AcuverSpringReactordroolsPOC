package com.landmarkgroup.api.returnpolicyenquiry.apps.OmsSalesOrderRequestAndResponseModel;

public class LinePriceInformation {
}
