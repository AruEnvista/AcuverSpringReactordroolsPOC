package com.landmarkgroup.api.returnpolicyenquiry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReturnPolicyEnquiryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReturnPolicyEnquiryApplication.class, args);
	}

}
