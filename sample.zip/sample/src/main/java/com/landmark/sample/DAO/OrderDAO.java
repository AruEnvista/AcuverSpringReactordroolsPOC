package com.landmark.sample.DAO;

import com.landmark.sample.model.OrderRequest;
import com.landmark.sample.model.SalesOrder;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface OrderDAO extends ReactiveMongoRepository<OrderRequest, String> {

    Mono<SalesOrder> findByOrderNumber(String orderNo);

}
