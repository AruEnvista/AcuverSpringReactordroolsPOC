package com.landmark.sample.model;

import java.math.BigDecimal;
import java.math.BigInteger;

public class SalesOrderLines {

    private String itemId;
    private BigDecimal returnQuanity;
    private boolean isManagerOverride;
    private BigDecimal maxReturnableQuantity;
    private BigDecimal orderedQuantity;
    private boolean isReturnable;
    private boolean isWithinReturnWindow;
    private BigInteger returnWindowPeriod;
    private String deliveryType;
    private String departmentId;
    private BigDecimal unitPrice;
    private BigDecimal discount;
}
