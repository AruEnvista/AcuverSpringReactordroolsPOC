package com.landmark.sample.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.math.BigInteger;

@Document(collection = "DrollsOrder")
@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class OrderLine {
    private String itemId;
    private BigDecimal returnQuanity;
    private boolean isManagerOverride;
    private BigDecimal maxReturnableQuanity;
    private BigDecimal orderedQuality;
    private boolean isReturnable;
    private boolean isWithinReturnWindow;
    private BigInteger returnWindowPeriod;
    private String deliveryType;
    private String departmentId;
}
