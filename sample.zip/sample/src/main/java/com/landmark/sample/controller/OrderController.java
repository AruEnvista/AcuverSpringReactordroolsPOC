package com.landmark.sample.controller;

import com.landmark.sample.model.OrderRequest;
import com.landmark.sample.model.SalesOrder;
import com.landmark.sample.service.OrderService;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.StatelessKieSession;
import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/returnPolicyValidation")
    public Publisher<ResponseEntity<SalesOrder>> validateReturns(@RequestBody OrderRequest orderRequest){
        return orderService.findByOrderNumber ( orderRequest.getOrderNumber ());
    }
}