package com.landmark.sample.service;

import com.landmark.sample.DAO.OrderDAO;
import com.landmark.sample.model.SalesOrder;
import lombok.extern.slf4j.Slf4j;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.StatelessKieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class OrderService {

    public static final String CACHEABLES_REGION_KEY = "OrderInformation";

    @Autowired
    private OrderDAO orderDAO;

    @Autowired
    private KieContainer kieContainer;

    private String sessionName = "rulesSessionpart2";

    public Mono<ResponseEntity<SalesOrder>> findByOrderNumber(String orderNo){

        StatelessKieSession kieSession = kieContainer.newStatelessKieSession(sessionName);
        return orderDAO.findByOrderNumber (orderNo).flatMap ( existingProduct -> {
            kieSession.execute ( existingProduct );
            return Mono.just ( existingProduct ).log ();
        } ).map ( o1 -> ResponseEntity.ok ( o1 ) )
                .defaultIfEmpty ( ResponseEntity.notFound ().build () );
    }

}