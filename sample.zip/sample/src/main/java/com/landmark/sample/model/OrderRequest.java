package com.landmark.sample.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document(collection = "DrollsOrder")
@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class OrderRequest {

    private String orderNumber;
    private String orderDate;
    private String territoryCode;
    private String channel;
    private String source;
    private boolean isLegacyOrder;
    private List<OrderLine> orderLines;

}
