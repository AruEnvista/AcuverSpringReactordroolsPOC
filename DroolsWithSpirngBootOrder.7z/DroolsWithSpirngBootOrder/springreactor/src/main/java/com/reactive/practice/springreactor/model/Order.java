package com.reactive.practice.springreactor.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document(collection = "DrollsOrder")
@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class Order {
    @Id
    private String id;
    private String orderNumber;
    private String title;
    private String Description;
    private List<LineItem> lineItems;
    private boolean itemReturnEligible;

    public static void returnOrder(String id) {
        System.out.println("Order is eligible for return " + id);
    }


}
