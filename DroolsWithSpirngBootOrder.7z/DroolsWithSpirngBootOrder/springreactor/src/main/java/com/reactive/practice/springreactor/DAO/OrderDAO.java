package com.reactive.practice.springreactor.DAO;

import com.reactive.practice.springreactor.model.Order;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;


@Repository
public interface OrderDAO extends ReactiveMongoRepository<Order, String> {

    Mono<Order> findByOrderNo(String orderNo);

    Order findByOrderNo1(String orderNo);
}
