package com.reactive.practice.springreactor.service;

import com.reactive.practice.springreactor.DAO.OrderDAO;
import com.reactive.practice.springreactor.model.Order;
import lombok.extern.slf4j.Slf4j;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import org.springframework.data.redis.core.ReactiveRedisTemplate;

@Slf4j
@Service
public class OrderService {

    public static final String CACHEABLES_REGION_KEY = "OrderInformation";

    @Autowired
    private OrderDAO orderDAO;

    @Autowired
    private KieContainer kieContainer;

    @Autowired
    private ReactiveRedisTemplate<String, Order> reactiveJsonBookRedisTemplate;

        public Mono<Order> findById(String id) {

            Mono<Order> order = orderDAO.findById ( id );
            //state less session
            KieSession kieSession = kieContainer.newKieSession("rulesSessionpart2");
            kieSession.insert(order);
            kieSession.fireAllRules();
            kieSession.dispose();
            return order;
    }


    public Mono<Order> findByOrderNo(String orderNo) {
        Mono<Order> order = orderDAO.findByOrderNo ( orderNo ).log ();
        KieSession kieSession = kieContainer.newKieSession("rulesSessionpart2");
        order.flatMap(existingProduct -> {
                    kieSession.insert(existingProduct);
                    kieSession.fireAllRules();
                    kieSession.dispose();
                    return order;

                });
        //state less session
        //return order;
        /*@PutMapping("{id}")
        public Mono<ResponseEntity<Product>> updateProduct(@PathVariable(value = "id") String id,
                @RequestBody Product product) {
            return repository.findById(id)
                    .flatMap(existingProduct -> {
                        existingProduct.setName(product.getName());
                        existingProduct.setPrice(product.getPrice());
                        kieSession.insert(existingProduct);
                        kieSession.fireAllRules();
                        kieSession.dispose();
                        return repository.save(existingProduct);
                    })
                    .map(updateProduct -> ResponseEntity.ok(updateProduct))
                    .defaultIfEmpty(ResponseEntity.notFound().build());*/
        return order;
        }


//the final one on Mono Object processing
    public Mono<ResponseEntity<Order>>  findByOrderNo2(String orderNumber) {
        KieSession kieSession = kieContainer.newKieSession ( "rulesSessionpart2" );

            Mono<Order> o1 = this.reactiveJsonBookRedisTemplate.opsForHash ().get ( CACHEABLES_REGION_KEY, orderNumber )
                    .cast ( Order.class );

            return o1.flatMap ( existingProduct -> {
                kieSession.insert ( existingProduct );
                kieSession.fireAllRules ();
                kieSession.dispose ();
                return Mono.just ( existingProduct );
            } ).map ( o2 -> ResponseEntity.ok ( o2 ) ).log ()
                    .switchIfEmpty ( orderDAO.findByOrderNo ( orderNumber ).flatMap ( existingProduct -> {
                        kieSession.insert ( existingProduct );
                        kieSession.fireAllRules ();
                        kieSession.dispose ();
                        return Mono.just ( existingProduct ).flatMap ( this::putToCache );
                    } ).map ( o3 -> ResponseEntity.ok ( o3 ) )
                            .defaultIfEmpty ( ResponseEntity.notFound ().build () ) ).log ();




           /* KieSession kieSession = kieContainer.newKieSession ( "rulesSessionpart2" );
            return orderDAO.findByOrderNo ( orderNumber).flatMap ( existingProduct -> {
                kieSession.insert ( existingProduct );
                kieSession.fireAllRules ();
                kieSession.dispose ();
                return Mono.just ( existingProduct ).flatMap ( this::putToCache );
            } ).map ( o1 -> ResponseEntity.ok ( o1 ) )
                  .defaultIfEmpty ( ResponseEntity.notFound ().build () );*/

    }

    private Mono<Order> putToCache(Order order) {
        return this.reactiveJsonBookRedisTemplate.opsForHash().put(CACHEABLES_REGION_KEY, order.getOrderNumber (), order)
                .log("Pushing to Cache").thenReturn(order);
    }


 //without mono object
    public Order findByOrderNo1(String orderNo) {
        Order order = orderDAO.findByOrderNo1 ( orderNo );
        //Order order1 = order.flatMap(response -> response.toString ());
        //state less session
        KieSession kieSession = kieContainer.newKieSession("rulesSessionpart2");
        kieSession.insert(order);
        kieSession.fireAllRules();
        kieSession.dispose();
        return order;
    }



}
