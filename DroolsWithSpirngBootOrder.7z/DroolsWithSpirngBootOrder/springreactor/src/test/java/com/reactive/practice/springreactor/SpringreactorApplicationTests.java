package com.reactive.practice.springreactor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringreactorApplicationTests {

	@Test
	void contextLoads() {
	}

}
